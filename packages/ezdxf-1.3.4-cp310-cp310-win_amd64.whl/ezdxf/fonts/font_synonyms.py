# Copyright (c) 2024, Manfred Moitzi
# License: MIT License

FONT_SYNONYMS = {
    "ariblk.ttf": "Arial Black.ttf",
    "comic.ttf": "Comic Sans MS.ttf",
    "arialuni.ttf": "Arial Unicode.ttf",
    "times.ttf": "Times New Roman.ttf",
    "trebuc.ttf": "Trebuchet MS.ttf",   
}
